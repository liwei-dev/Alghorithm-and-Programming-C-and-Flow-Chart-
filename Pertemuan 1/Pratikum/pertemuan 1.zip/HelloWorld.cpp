#include <iostream>
using namespace std;

int main () {
	// Menampilkan output Hello World -- Single Line Command
	/* Menampilkan output 
					Hello World -- Double line Command
	*/ 
	cout << "Hello World";
	return 0;
}

