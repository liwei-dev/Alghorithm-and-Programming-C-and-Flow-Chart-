#include <iostream>
using namespace std;

void matriks () {
	char nama[20];
	int npegawai, gaji, jumlahanak;
	
	if (nama != "SELESAI" ){
		do{
			cout << "Nama pegawai : ";
			cin >> nama; 
			cout << "Nomor pegawai (contoh, 10003) : ";
			cin >> npegawai;
			cout << "Gaji pegawai : ";
			cin >> gaji;
			cout << "Jumlah anak : ";
			cin >> jumlahanak;
		}
		while (nama != "SELESAI" || gaji != 0 || jumlahanak != 0);
	}
	else (nama == "SELESAI" );{
		cout << "No 	Nama pegawai	Nomor pegawai	Gaji pegawai 	Jumlah anak"
		for (int i = 0; i++; ){
			cout << i << nama << gaji << jumlahanak;
		}
	}
}

int gaji(int gaji, int jumlahanak, int& tunjangan){
 tunjangan = gajipegawai / jumlahanak;
}

void matriks (){
 char nama[20];
 int npegawai, gaji, jumlahanak;

 cout << endl << "No  Nama pegawai Nomor pegawai Gaji pegawai  Jumlah anak";
  for (int i = 0; i++; ){
   cout << i+1 << nama << gaji << jumlahanak; 
  }
}


int main (){
 int gaji, jumlahanak, tunjangan;
 cout << "Program Matriks Gaji Pegawai" << endl << endl;
 input ();
 gaji (gaji, jumlahanak, tunjangan);
 matriks ();
 
}
