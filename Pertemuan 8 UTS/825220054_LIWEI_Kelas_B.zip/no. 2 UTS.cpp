#include <bits/stdc++.h>
using namespace std; 

int main (){
	int jam1, menit1, jam2, menit2;
	int lama;
	int jam, menit;
 
//input
	cout << "Masukan waktu mulai (contoh 08:30) = " << endl;;
	cin >> jam1;
	cin >> menit1;
	cout << endl << jam1 << ":" << menit1 << endl << endl; //untuk menginput jam, masukan digit lalu enter, dan masukan 2 digit sisanya lalu enter 
	cout << "Masukan waktu selesai (contoh 09:30) = " << endl;
	cin >> jam2;
	cin >> menit2;
	cout << endl << jam2 << ":" << menit2 << endl << endl; 
 
//rumus
	lama = ((jam2 * 60) + menit2) - ((jam1 * 60) + menit1);
	jam = lama / 60;
	menit = lama - (jam*60) ;
 
 
	cout<<"Lama(dalam menit) = "<< lama << endl;
	cout<<"Lama(dalam jam dan menit) = "<< jam << " jam " << menit << " menit ";

return 0;
}
