#include <iostream>
using namespace std;

int main () {
    int password;
    int input;
    
    password + 12345;
    
    cout << "**PROGRAM CEK PASSWORD**" << endl << endl;
    do{
    	cout << "Masukkan Password : ";
    	cin >> input;
	}
	while (input != password);
	
	cout << endl << "Password CORRECT";
	
	return 0;	
}
